# Simulate VMware VM creation
param([string]$Username)
Write-Host "✅ Created VM image for $Username using CyberSecTemplate01"
