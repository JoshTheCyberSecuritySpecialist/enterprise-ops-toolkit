def enroll_macos(email):
    print(f"✅ Enrolled {email}'s Mac to Jamf Pro")
    print("✅ FileVault encryption enabled")
    print("✅ Device tagged for security baseline")
